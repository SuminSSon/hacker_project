package project.khu.webapi;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


//@RestController
//@RequiredArgsConstructor
//class JwtControllerTest {
//
//    @RequestMapping("/auth/login")
//    public String login(@RequestParam String userId){
//        if(userId.equals("admin")){
//            Authentication authentication = new UserAuten
//        }
//    }
//}