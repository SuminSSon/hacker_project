package project.khu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KhuApplicationTests {

	@Test
	void contextLoads() {
	}

}
